<?php
/**
 * User: Vishnu Vardhan G
 * Date: 14/11/19
 * Time: 15:58 AM
 */
namespace models;

use Connection\DB;
use PDO;
use Throwable;

class paymentAndBooking 
{
    public static function payment($user_data){
        try{
            $sql = "INSERT INTO t_payments (r_user_id,total_amount) VALUES (:user_id,:amount)";
            $stmt = DB::getConnection()->prepare($sql);
            $stmt->execute([
                ':user_id'=> $_SESSION['CurrentUserData']['user_id'],
                ':amount' => $_SESSION['amount']
            ]);
            $sql = "SELECT * FROM t_payments ORDER BY payment_id DESC limit 1";
            $stmt = DB::getConnection()->prepare($sql);
            $stmt->execute();
            $payments_data = $stmt->fetch(PDO::FETCH_ASSOC);
            // $sql = "INSERT INTO t_booking_details (r_payment_id,seat_classes,seat_numbers,seat_count) VALUES (:r_payment_id,:seat_classes,:seat_numbers,:seat_count)";
            // $stmt = DB::getConnection()->prepare($sql);
            // $stmt->execute([
            //     ':r_payment_id'=> $payments_data['payment_id'],
            //     ':seat_classes' => $_SESSION['amount']
            // ]);
            return $payments_data['payment_id'];
        } catch(Throwable $e){
            dd($e->getMessage()." at line ".$e->getLine()." in ".$e->getFile());
        }
    }
}