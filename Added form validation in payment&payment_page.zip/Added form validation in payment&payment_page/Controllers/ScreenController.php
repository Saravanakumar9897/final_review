<?php
/**
 * @Author:Banupriya
 * @Description:This ScreenController will show the available screen running in theatre.
 * Date: 31/10/19
 * Time: 3:54 PM
 */

namespace Controllers;

use Models\ClassType;
use Models\Screen;
use Models\Theatre;
use Request\Request;
use Throwable;
class ScreenController
{
    //This constructor function  will check wheather the user is superAdmin or Admin
    public function __construct()
    {
        auth(['SuperAdmin','Admin']);
    }

    //This screenIndex function will show the available screens in theatre
    public function screenIndex(){
        try {
            //This shows will contain the model and all available screens using the all().
            $screens = Screen::allWithRelation();
            //Then the fetched screens are displayed in view page through export function
            export('backend/screens/view_all',$screens->objects);
        } catch (Throwable $e) {
            throwError($e->getMessage()." at line ".$e->getLine()." in ".$e->getFile());
        }
    }

    //This screenForm function will fetch the form from the screens folder and display it in the view page
    public function screenForm(){
        try {
            $theatres = Theatre::all();
            $classTypes = ClassType::all();
            export('backend/screens/create_form',[$theatres->objects,$classTypes->objects]);
        } catch (Throwable $e) {
            throwError($e->getMessage()." at line ".$e->getLine()." in ".$e->getFile());
        }
    }

    //This screenStore function will check the Request method first,then get values as $request and the values are stored $formData then this shows are inserted into datebase,then redirected to screenIndex page
    public function screenStore(Request $request){
        try {
            $formData = $request->getBody();
            $classTypes = ClassType::all();
            $allClasses = $classTypes->objects;
            $Array = [];
            foreach ($allClasses as $allClass){
                array_push($Array, [str_replace(' ','_',$allClass->class_type_name)=>$formData[str_replace(' ','_',$allClass->class_type_name)]]);
                unset($formData[str_replace(' ','_',$allClass->class_type_name)]);
            }
            $formData['classes_seats'] = json_encode($Array);
            Screen::insert($formData);
            redirect('/screenIndex');
        } catch (Throwable $e) {
            throwError($e->getMessage()." at line ".$e->getLine()." in ".$e->getFile());
        }
    }

    //This screenShow function will check the Request method first,then it shows the values from the stored variable in view page
    public function screenShow(Request $request){
        try {
            $formData = $request->getBody();
            $screen = Screen::selectWithRelation($formData['screen_id']);
            export('backend/screens/show',$screen);
        } catch (Throwable $e){
            throwError($e->getMessage()." at line ".$e->getLine()." in ".$e->getFile());
        }
    }


    //This screenEditForm function will fetch the existing values from the screens folder and display it in the edit form
    public function screenEditForm(Request $request){
        try {
            $formData = $request->getBody();
            $screen = Screen::selectWithRelation($formData['screen_id']);
            $theatres = Theatre::all();
            $classTypes = ClassType::all();
            export('backend/screens/edit_form',[$screen,$theatres->objects,$classTypes->objects]);
        } catch (Throwable $e) {
            throwError($e->getMessage()." at line ".$e->getLine()." in ".$e->getFile());
        }
    }

    //This screenUpdate function will check the Request method first,then get values as $request and the values are stored $formData then this shows are updated into datebase,then redirected to screenIndex page
    public function screenUpdate(Request $request){
        try {
            $formData = $request->getBody();
            $classTypes = ClassType::all();
            $allClasses = $classTypes->objects;
            $Array = [];
            foreach ($allClasses as $allClass){
                array_push($Array, [str_replace(' ','_',$allClass->class_type_name)=>$formData[str_replace(' ','_',$allClass->class_type_name)]]);
                unset($formData[str_replace(' ','_',$allClass->class_type_name)]);
            }
            $formData['classes_seats'] = json_encode($Array);
            Screen::update($formData);
            redirect('/screenIndex');
        } catch (Throwable $e) {
            throwError($e->getMessage()." at line ".$e->getLine()." in ".$e->getFile());
        }
    }

    //This screenDelete function will check the Request method first,then get values as $request and the particular values are stored $formData then this shows are deleted into database,then redirected to screenIndex page
    public function screenDelete(Request $request){
        try {
            $formData = $request->getBody();
            Screen::findDelete($formData['screen_id']);
            redirect('/screenIndex');
        } catch (Throwable $e){
            throwError($e->getMessage()." at line ".$e->getLine()." in ".$e->getFile());
        }
    }

    public function getScreenOfTheatre(Request $request){
        $formData = $request->getBody();
        $screens = Screen::multSelect(['screen_id','screen_name','total_seats'],['r_theatre_id'=>$formData['r_theatre_id']]);
        return json_encode($screens);
    }
}