<?php
/**
* @Author:Banupriya
* @Description:This page will find out the request method based on the request method the below function will be executed .
*/
namespace Request;
use Sessions\Session;


class Request extends Session implements IRequest
{
    public $GET = [];
    public $POST = [];
    public $FILES = [];

    //This constructor function will check the availabe SERVER variables from the listed server variables the required the server variable is choosed.
    function __construct()
    {
        //This foreach condition will fetch the SERVER variables and required server variable will be converted into CAMELCASE dynamically.
        foreach($_SERVER as $key => $value)
        {
            $this->{$this->toCamelCase($key)} = $value;
        }
        //If the selected SERVER variable method is GET then the below line will be executed 
        if ($this->requestMethod === "GET"){
            foreach ($_GET as $key => $value){
                $this->$key = $value;
            }
            $this->GET = $_GET;
        }
        //If the selected SERVER variable method is POST then the below line will be executed
        if ($this->requestMethod === "POST"){
            foreach ($_POST as $key => $value){
                $this->$key = $value;
            }
            $this->POST;
        }
        //If the selected variable has file type kind of extention then the below line will be executed.
        foreach ($_FILES as $key => $value){
            $this->$key = $value;
        }
        $this->FILES = $_FILES;
    }

    //This function will get an string from invoked constructor then the string will be converted to lower case & stored in a variable and that variable exploded using preg_match_all function to convert it into camelcase
    private function toCamelCase($string)
    {
        $result = strtolower($string);
        preg_match_all('/_[a-z]/', $result, $matches);
        foreach($matches[0] as $match)
        {
            $c = str_replace('_', '', strtoupper($match));
            $result = str_replace($match, $c, $result);
        }
        return $result;
    }

    /**
     *  string
     * To get Authorization Token From Request
     */
    public function getHttpAuthorization(){
        if (isset($this->httpAuthorization)){
            return $this->httpAuthorization;
        }else{
            return "HttpAuthorization Token Not Found";
        }
    }

   //The getBody function  is invoked by the interface,then the body data is collected and the below function will be executed.
    public function getBody()
    {
        if($this->requestMethod === "GET")
        {
            foreach($_GET as $key => $value)
            {
                $body[$key] = filter_input(INPUT_GET, $key, FILTER_SANITIZE_SPECIAL_CHARS);
            }
            return $body;
        }
        if ($this->requestMethod == "POST")
        {
            $body = array();
            foreach($_POST as $key => $value)
            {
                $body[$key] = filter_input(INPUT_POST, $key, FILTER_SANITIZE_SPECIAL_CHARS);
            }
            return $body;
        }
    }

}
?>