<?php
/**
*Author: Saravanakumar.N
*Description: Getting the details from the database for the user ui model for populating datas
*created on : 13.11.2019
*/
namespace Models;

use Classes\Model;
use PDO;
use Connection\DB;
use Throwable;

class user_movie 
{
#class file for the details of movies to be given to the user
	public static function all_movies(){
	try{
            $stmt = DB::getConnection()->prepare("SELECT * from t_movies");
            $stmt->execute();
            $AllRows = [];
            while ($row = $stmt->fetch()){
                $AllRows[] = $row;
    	    }
            return $AllRows;
        } catch (Throwable $e){
            dd($e->getMessage()." at line ".$e->getLine()." in ".$e->getFile());
        }
	}
    public static function now_showing(){
    try{
            $stmt = DB::getConnection()->prepare("SELECT * from t_movies where release_date < 20191113");
            $stmt->execute();
            $AllRows = [];
            while ($row = $stmt->fetch()){
                $AllRows[] = $row;
            }
            return $AllRows;
        } catch (Throwable $e){
            dd($e->getMessage()." at line ".$e->getLine()." in ".$e->getFile());
        }
    }
    public static function coming_soon(){
    try{
            $stmt = DB::getConnection()->prepare("SELECT * from t_movies where release_date >= 20191113");
            $stmt->execute();
            $AllRows = [];
            while ($row = $stmt->fetch()){
                $AllRows[] = $row;
            }
            return $AllRows;
        } catch (Throwable $e){
            dd($e->getMessage()." at line ".$e->getLine()." in ".$e->getFile());
        }
    }
    public static function movieofscreens(){
        try{
            $stmt = DB::getConnection()->prepare("SELECT 
                t_movies.name,t_movies.description,t_movies.banner_image,t_movies.list_image,
                t_screens.screen_name,
                t_theatres.theatre_name, 
                t_shows.show_name,
                t_movies.actor,
                t_movies.actress,
                t_movies.description,
                t_movies.duration,
                t_movies.director,
                t_movies.producer,
                t_movies.movie_id
                from t_movies 
                INNER JOIN t_movie_of_screens ON 
                t_movie_of_screens.r_movie_id = t_movies.movie_id 
                INNER JOIN t_screens ON
                t_screens.screen_id = t_movie_of_screens.r_screen_id 
                INNER JOIN t_theatres on 
                t_theatres.theatre_id = t_screens.r_theatre_id
                INNER JOIN t_shows ON 
                t_movie_of_screens.r_show_id = t_shows.show_id
                ");
            $stmt->execute();
            $AllRows = [];
            while ($row = $stmt->fetch()){
                $AllRows[] = $row;
            }
            return $AllRows;
        } catch (Throwable $e){
            dd($e->getMessage()." at line ".$e->getLine()." in ".$e->getFile());
        }
    }
}