<?php
/**
 * Author: Saravanakumar.N
 * Description: controller for performing the Actions on the FrontEnd of the user interfaces.    
 * Date: 10/11/19
 * Time: 4:41 PM
 */

namespace Controllers;


use Models\MovieCategory;
use Models\MovieOfScreen;
use Models\user_movie;
use Models\paymentAndBooking;
use Request\Request;

class FrontController
{
    public function home(Request $request) {
        $movieCategories=MovieCategory::all();
        $movieOfScreens = MovieOfScreen::allWithRelation();
        export('frontend/home',[$movieCategories->objects,$movieOfScreens->objects]);
    }

    public function _details(Request $request) {
        $formData = $request->getBody();
        $movieOfScreen = MovieOfScreen::selectWithRelation($formData['movie_of_screen_id']);
        export('frontend/details',$movieOfScreen);
    }

    public function _select_shows(Request $request) {
        $formData = $request->getBody();
        $movieOfScreen = MovieOfScreen::selectWithRelation($formData['movie_of_screen_id']);
        export('frontend/select_show',$movieOfScreen);
    }

    public function _total_seat_count(Request $request) {
        $formData = $request->getBody();
        export('frontend/seat_numbers','');
    }

    public function _select_seats(Request $request) {
        $formData = $request->getBody();
        $movieOfScreen = MovieOfScreen::selectWithRelation($formData['movie_of_screen_id']);
        export('frontend/seats_layout',$movieOfScreen);
    }

    public function _payment_preview(Request $request) {
        if(isset($_SESSION['CurrentUserData']['r_role_id'])){
            $formData = $request->getBody();
            $movieOfScreen = MovieOfScreen::selectWithRelation($formData['movie_of_screen_id']);
            export('frontend/payment_page',$movieOfScreen);
        }else{
            export('backend/authentication/adminLogin','');
        }
    }

    public function _payment(Request $request) {
        $formData = $request->getBody();
        $movieOfScreen = MovieOfScreen::selectWithRelation($formData['movie_of_screen_id']);
        export('frontend/payment',$movieOfScreen);
    }
    public function home_page(Request $request){
        $movies = user_movie::all_movies();
        export('frontend/home',$movies);
    }
    public function now_showing(Request $request){
        $movies = user_movie::now_showing();
        export('frontend/now_showing',$movies);
    }
    public function coming_soon(Request $request){
        $movies = user_movie::coming_soon();
        export('frontend/coming_soon',$movies);
    }
    public function details(Request $request){
        $movies = user_movie::movieofscreens();
        export('frontend/details',$movies);
    }
    public function select_shows(Request $request) {
        $movieOfScreen = user_movie::movieofscreens();
        export('frontend/select_show',$movieOfScreen);
    }
    public function total_seat_count(Request $request) {
        $movieOfScreen = user_movie::movieofscreens();
        export('frontend/seat_numbers',$movieOfScreen);
    }
    public function select_seats(Request $request) {
        $movieOfScreen = user_movie::movieofscreens();
        export('frontend/seats_layout',$movieOfScreen);
    }
    public function payment_preview(Request $request) {
        if(isset($_SESSION['CurrentUserData']['r_role_id'])){
            $formData = $request->getBody();
            $_SESSION['count'] = $formData['count'];
            $_SESSION['amount'] = $formData['amount'];
            $movieOfScreen = user_movie::movieofscreens();
            export('frontend/payment_page',$movieOfScreen);
        }else{
            $_SESSION['count'] = $formData['count'];
            $_SESSION['amount'] = $formData['amount'];
            export('backend/authentication/adminLogin','');
        }
    }
    public function payment(Request $request) {
        $formData = $request->getBody();
        $_SESSION['amount'] = $formData['amount'];
        $_SESSION['count'] = $formData['count'];
        $_SESSION['class'] = $formData['class'];
        $_SESSION['class_type'] = $formData['class_type'];
        $_SESSION['seat_no'] = $formData['seat_no'];
        $_SESSION['movie_id']= $formData['movie_id'];
        $movieOfScreen = user_movie::movieofscreens();
        export('frontend/payment',$movieOfScreen);
    }

    public function payment_submit(Request $request) {
        $formData = $request->getBody();
        $data = paymentAndBooking::payment($formData);
        print_r($data);
        redirect('/ticket_view');
    }

    public function ticket_details() {
        $data = paymentAndBooking::ticket_details();
        if(isset($_SESSION['CurrentUserData'])){
            export('frontend/ticket_details',$data);
        }else{
            redirect('/');
        }
    }
}