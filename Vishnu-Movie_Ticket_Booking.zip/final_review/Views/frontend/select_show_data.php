<?php 
$movies = import();
$uri = explode('?',$_SERVER['REQUEST_URI']);
$movie_name = $uri[1];
foreach ($movies as $key => $value) {
	# code...
	if(strtolower($movies[$key][0])==$movie_name){
		$movieOfScreen[] = $movies[$key];
} 
}
?>