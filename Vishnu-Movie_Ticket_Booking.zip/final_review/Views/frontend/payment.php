<?php $movieOfScreen = import();
    $year = date('Y');
    $month = date('m');
    $date = date('d');
    $max_date = $date + 4;
    $movie_id = $_REQUEST['movie_id'];
    $theatre_id = $_REQUEST['theatre_id'];
    foreach ($movieOfScreen as $key => $value) {
    if($movieOfScreen[$key]['movie_id']==$movie_id){
        $movie_data[]=$movieOfScreen[$key];
    }

    }
    $movie=$movie_data[$theatre_id];
     echo "</pre>";
?>
<div><br>
    <span class="details_remainder" id="movieName"><?php echo $movie['name']; ?></span>
    <a href="/" class="change_details"><i class="fa fa-close fa-xs"></i></a>
    <span class="details_remainder" id="classType"><?php echo $movie['theatre_name'].'-'.$movie['show_name']; ?></span>
    <a href="<?php echo baseURL().'/select_show?movie_of_screen_id='.$movieOfScreen->r_movie_id; ?>" class="change_details"><i class="fa fa-close fa-xs"></i></a>
    <span class="details_remainder" id="movieName"><?php echo 'Total Amount='.$_SESSION['amount']; ?></span>
    <a onclick="seat_selection_page();" href="" class="change_details"><i class="fa fa-close fa-xs"></i></a>
    <span class="details_remainder" id="movieName"><?php echo 'Seat Count='.$_SESSION['count']; ?></span>
    <a href="<?php echo baseURL().'/select_show?movie_of_screen_id='.$movieOfScreen->r_movie_id; ?>" class="change_details"><i class="fa fa-close fa-xs"></i></a>
</div><br>
<div class="card-header">Enter your card details</div>
    <div id="detail_catcher" class="card-body">     
    <!-- form container start -->
        <form action="/payment_submit">
            <table class="table table-sm table-borderless">
                <tr>
                    <td colspan="3"><span id="formCheck"></span></td>
                </tr>
                <tr>
                    <td class="text-center">Amount</td>
                    <td class="text-left">:</td>
                    <td class="text-left"><span><?php echo $_SESSION['amount']; ?></span></td>
                </tr>
                <tr>
                    <td class="text-center">Card Number</td>
                    <td class="text-left">:</td>
                    <td class="text-left"><input type="text" id="cardNumber" name="cardNumbar" placeholder="XXXX XXXX XXXX XXXX" onkeyup="cardNumberCheck();" required="true">
                    <span id="cardNumberCheck"></span>
                    </td>
                </tr>
                <tr>
                    <td class="text-center">Name on the card</td>
                    <td class="text-left">:</td>
                    <td class="text-left"><input type="name" id="cardHolder" name="cardHolder" placeholder="ex...sundar" onkeyup="cardHolderCheck();" required="true">
                    <span id="cardHolderCheck"></span>
                    </td>
                </tr>
                <tr>
                    <td class="text-center">Expiry Date</td>
                    <td class="text-left">:</td>
                    <td class="text-left"><input type="Number" id="ExpiryMonth" name="ExpiryDate" placeholder="MM" max="12" min="1" autocomplete="cc-exp-month" required="true">
                    <input type="Number" id="ExpiryYear" name="ExpiryYear" placeholder="YYYY" min="2020" max="2060" autocomplete="cc-exp-month" required="true"></td>
                </tr>
                <tr>
                    <td class="text-center">CVV</td>
                    <td class="text-left">:</td>
                    <td class="text-left">
                        <input type="Number" id="Cvv" name="CVV" placeholder="CVV" min="0" max="999" maxlength="3" required="true">
                    </td>
                </tr>
                <tr>
                    <td colspan="2" class="text-right"><input onclick="return finalValidate();" id="submit" type="submit" class="btn btn-info" value="Pay" name="paymentSubmit"></td>
                </tr>
            </table>
        </form>
    <!-- form container end -->
    </div>
</div>


<!-- <script>
$(document).ready(function(){
  $("cardNumber").keydown(function(){
    alert("fghj");
  });
  $("cardNumber").keyup(function(){
    $("cardNumber").css("background-color", "pink");
  });
});
</script> -->