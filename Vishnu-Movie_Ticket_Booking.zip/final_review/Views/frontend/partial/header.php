<div class="header">
<header class="container-fluid">    
    <div class="logo"><a href="<?php echo baseURL(); ?>">Logo</a></div>
    <nav>
        <ul>
            <li><a href="<?php echo baseURL().'/'; ?>"><i class="fa fa-home"></i> Home</a></li>
            <li>
                <?php if(!isset($_SESSION['CurrentUserData']['r_role_id'])){ ?>
                <a href="<?php echo baseURL().'/admin'; ?>"><i class="fa fa-lock"></i>  Sign In</a>
                <?php }else{ ?>
                <a href="<?php echo baseURL().'/logout'; ?>"><i class="fa fa-lock"></i> Sign Out<OUTPUT></OUTPUT></a>
                <?php } ?>
            </li>
        </ul>
    </nav>
    <div class="menu-toggle"><i class="fa fa-bars" aria-hidden="true"></i></div>
</header></div>