<!DOCTYPE html>
<html>
<head>	
	<?php view('frontend/partial/seat_selection_library.php') ?>
</head>
<body>
	<!-- main container start -->
	<div class="col-md-12 form-group">
        <div class="card" style="height: 100%">
            <div class="card-header">Enter the number of seats:</div>
                <div class="card-body">    	
				<!-- form container start -->
					<form>
                    <table class="table table-sm table-borderless">
                        <tr>
                            <td class="text-center">
								<!-- select box -->
								<select class="select-drop btn btn-info" onchange="seatview(this.value)">
									<option value="1">Select total Number of seats</option>
									<?php for($i = 1;$i <= 9;$i++){ ?>
										<option value="<?php echo $i; ?>"><?php echo $i; ?></option>
									<?php } ?>		
								</select>
								<!-- select box end -->
							</td>
							<td class="text-left">
								<input onclick="nextPage();" type="button" id="submit" class="btn btn-info" value="Next" name="submission">
							</td>
                        </tr>
                    </table>
                    </form>
				<!-- form container end -->
                </div>
            </div>
        </div>
	</div>
</body>
</html>