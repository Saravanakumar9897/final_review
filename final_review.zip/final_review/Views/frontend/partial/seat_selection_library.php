<!DOCTYPE html>
<html>
<head>
	<!-- title of the page -->
	<title>Select Seat numbers</title>
	<!-- library function including the head of the html page -->
	<link rel="stylesheet" href="../../../Assets/backend/seat_css/style.css">
	<link rel="stylesheet" href="../../../Assets/backend/seat_css/bootstrap.css">
	<link rel="stylesheet" href="../../../Assets/backend/seat_css/bootstrap.min.css">
	<link rel="stylesheet" href="../../../Assets/backend/seat_css/bootstrap-theme.min.css">
	<link rel="stylesheet" href="../../../Assets/backend/seat_css/bootstrap-theme.css">
	<script type="text/javascript" src="../../../Assets/backend/seat_js/jquery.js"></script>
	<script type="text/javascript" src="../../../Assets/backend/seat_js/bootstrap.js"></script>
	<script type="te xt/javascript" src="../../../Assets/backend/seat_js/bootstrap.min.js"></script>
</head>
</html>