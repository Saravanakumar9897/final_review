<?php 
$movies = import();
$movie_name = $_REQUEST['movie_of_screen_id'];
foreach ($movies as $key => $value) {
	# code...
	if(strtolower($movies[$key]['movie_id'])==$movie_name){
		$movie[] = $movies[$key];
} 
}
$t_id = $_REQUEST['theatre_id'];
$movieOfScreen = $movie[$t_id];
?>