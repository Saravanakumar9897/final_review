<title><?php echo constant('APP_NAME'); ?></title>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<!-- Main CSS-->
<link rel="stylesheet" type="text/css" href="<?php echo asset('backend/css/main.css') ?>">
<!-- Font-icon css-->
<link href="<?php echo asset('backend/css/font-awesome.min.css') ?>" rel="stylesheet">
<script src="https://cdn.ckeditor.com/4.13.0/standard/ckeditor.js"></script>